$(function() {
	let hello = $("<div>Hello, jQuery!</div>");
	hello.appendTo("body");
});
